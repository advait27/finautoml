# tests package for finance_automl
